# CA → Kong Migration Automation — Interview Prep

## Resume Bullets

### Full version (Experience section, 4–5 bullets)

- Migrated 11 production APIs from CA (Broadcom) Layer 7 to Kong API Gateway (Konnect), progressing from fully manual migration (branch/folder scaffolding, OAS authoring, plugin configuration, deployment validation) to a self-built AI automation pipeline.
- Architected and built 20+ specialized AI agents (Claude-based) that automate the end-to-end CA→Kong migration: CA policy XML parsing, OpenAPI spec generation, Kong plugin authoring (auth, rate limiting, threat protection, custom Lua transforms), and deployment validation against live Kong Konnect control planes.
- Built a dedicated, flow-aware security-audit agent that reviews every migrated service's assembled Kong configuration against PCI DSS v4.0, CBUAE regulatory requirements, and the OWASP API Security Top 10 — calibrating expectations and severity differently for inbound (external-facing), outbound, and internal traffic flows rather than applying a one-size-fits-all rubric.
- Designed and shipped a reusable Claude Skill that packages the entire multi-agent migration pipeline — including deployment validation and the security audit — into a single invocable workflow, turning a multi-step manual process into a one-command operation for future migrations.
- Iteratively hardened the agent pipeline against real production traffic patterns and backend behaviors, correcting configuration gaps (auth schemes, environment provisioning, request/response transformation logic) that were only surfaced through live validation — encoding every fix permanently into the automation rather than one-off patches.

### Condensed version (3 bullets)

- Automated the CA (Broadcom) Layer 7 → Kong API Gateway migration process by building 20+ specialized AI agents, reducing a fully manual multi-step workflow (scaffolding, OpenAPI authoring, plugin configuration, deployment validation) to an automated pipeline used to migrate 11 production APIs.
- Added a flow-aware security-audit agent to the pipeline that maps every migrated service's configuration to PCI DSS, CBUAE, and OWASP API Top 10 controls, calibrating findings differently for inbound, outbound, and internal traffic rather than a generic checklist.
- Packaged the automation into a reusable Claude Skill, enabling one-command execution of the full migration-to-deployment-validation-to-security-audit pipeline for future API onboarding.

### One-liner (Skills/Projects summary line)

- **AI-Driven API Migration & Security Automation** — Built a 20+ agent Claude automation pipeline (including a PCI DSS/CBUAE/OWASP-mapped security-audit agent) + custom Claude Skill that migrated 11 production APIs from CA Layer 7 to Kong API Gateway, replacing a fully manual process.

> Adjust the "20+ agents" / "11 services" numbers to whatever you can stand behind in an interview.

---

## Interview Questions to Expect

Weighted toward what's most likely to actually get asked given this resume claim — the AI-automation angle draws more scrutiny than the plain "migrated APIs" part.

### 1. "Walk me through it" — opening questions
- What problem were you solving, and why was the manual process painful enough to automate?
- Walk me through one full migration, start to finish — what does the pipeline actually do at each step?
- What made you go from "just do it manually" to "build 20 agents"? What was the tipping point?

### 2. Skepticism about the AI-automation claim — expect this, prepare for it
This is the highest-probability line of questioning. Interviewers will want to know how much is genuinely automated vs. you steering an LLM turn-by-turn.

- **"How much of this did the AI actually do vs. you?"** — be ready to describe specific bugs the agents got wrong and how *you* caught and fixed them (e.g., a security config template that was wrong for half of service types, missing env vars that broke builds, incorrect Lua field mappings) — this proves you understand the system, not just prompted it.
- If you fully automated it, why did it still need correction after 11 services? What does that say about the reliability boundary?
- How do you know the agent's output is *correct*, not just plausible-looking? What's your verification story?
- What happens when an agent hallucinates a config value (e.g., a fake vault path or backend host)? How is that guarded against?

### 3. Technical depth — Kong / API Gateway domain
- What's the difference between Kong's `openid-connect` plugin doing local JWT verification vs. token introspection — and when do you need one vs. the other?
- Explain mTLS termination at the gateway layer vs. at Kong itself — why does Kong need a header-based cert-auth plugin instead of terminating TLS directly?
- How do you handle a backend that speaks SOAP/XML when the consumer-facing API is JSON? Where does that translation logic live, and why not just use a generic transformer plugin?
- What's the difference between `deck gateway validate`/`diff`/`sync` — why would you deliberately never run one of them in an automated pipeline?
- How do you reproduce a legacy gateway's custom error-handling/status-remapping behavior on a different platform?

### 4. System design — the agent architecture itself
- Why break this into ~20 single-purpose agents instead of one big agent (or one big script)?
- How do agents share context/state across steps without redoing each other's work?
- How would you extend this pipeline to support a new backend protocol (e.g., gRPC) it doesn't handle today?
- What's the failure mode if step 3 of the pipeline produces bad output — does step 4 blindly trust it? How would you build in a validation gate?

### 5. The Skill vs. Agent distinction (shows you understand the tooling, not just used it)
- What's the actual difference between an "agent" and a "skill" in this system? Why did you build the skill *after* the agents, not before?
- Could you have built the skill first and skipped building individual agents?

### 6. Rigor / validation story (this is your strongest ground — lean into it)
- How did you validate the migrated config was actually correct before calling it done — not just "it looks right"?
- Describe a real bug you found only by testing against a live system, that static review wouldn't have caught.
- Tell me about a time the automation produced something wrong, and how you traced it back to the root cause.

### 7. Impact / behavioral
- What would break if you handed this pipeline to a teammate who'd never seen it? What guardrails did you build in for that?
- What's the ROI here — time saved per migration, error rate before/after?
- What's the biggest limitation of this approach today, and what would you build next?

### 8. Security & compliance dimension (new — expect this given the security-audit agent)
- Why isn't a security audit a one-size-fits-all checklist? Walk me through why the same missing control means something different for an inbound vs. outbound vs. internal service.
- How do you keep a security-audit agent from drowning developers in false positives against your own house conventions (e.g., a config pattern you *deliberately* chose)?
- How do you map a gateway-level finding to an actual compliance control (PCI DSS, CBUAE, OWASP) instead of just saying "this looks insecure"?
- Where's the line between what the gateway should enforce vs. what the upstream service is responsible for? How does the agent avoid flagging something that's genuinely not Kong's job?
- Why does this agent only *report* findings and never apply fixes itself? What would change if you let it auto-remediate?
- How did you decide to fold this into one agent with a flow-aware rubric instead of three separate agents (one per flow)?

### Prep tip
Have 3–4 *specific* bugs/design-decisions ready to narrate in detail:
- The security-scheme variant mixup (wrongly reverting a correct config because of stale guidance)
- The missing env vars breaking the build
- The wrong Lua namespace/field mapping
- The security-audit rubric rejection — you were handed a generic audit prompt, recognized it would misfire across different traffic flows, and redesigned it to calibrate per flow instead of applying it blindly

Concrete "here's exactly what went wrong (or what I caught before it went wrong) and how I found it" stories will carry you through almost every question above, including the skeptical ones.

---

## Spoken Opening

### Full version (~75–90 sec)

> "One of the projects I'm most proud of is automating our migration from a legacy API gateway — CA Layer 7 — onto Kong. When I started, every migration was fully manual: creating the branch and folder structure by hand, writing the OpenAPI spec, configuring every Kong plugin — auth, rate limiting, threat protection — one at a time, and then manually validating the deployment. It worked, but it was slow and error-prone, and the same kinds of mistakes kept resurfacing on every new service.
>
> So I started building a set of specialized AI agents — about 20 of them — each owning one piece of that pipeline: one parses the legacy export, one scaffolds the service, several author individual Kong plugins, one handles deployment validation against the live gateway. I used that pipeline to migrate 11 production APIs, and every time I found a bug — a wrong config default, a missing environment variable, incorrect logic in a custom transform — I fixed it once, in the agent itself, so every future migration inherited that fix automatically instead of me re-solving the same problem.
>
> More recently I added a security-audit agent to the end of that pipeline — it reviews every migrated service against PCI DSS, CBUAE, and the OWASP API Top 10. The first version of that audit prompt was written as one universal checklist, and I recognized that wouldn't actually work — the same missing control means something completely different depending on whether the traffic is coming from an external client, going out to a third-party provider, or staying entirely internal. So I redesigned it to determine the traffic flow first and calibrate every finding's severity against that, instead of producing a generic, noisy report.
>
> Once the pipeline was proven against real services, I packaged the whole thing into a single reusable Skill, so kicking off a new migration — including its security audit — is now one command instead of a multi-step manual process."

### Short version (~20–25 sec, for tight intros)

> "I automated our legacy-to-Kong API gateway migration — went from a fully manual, multi-step process to a pipeline of about 20 specialized AI agents, including a compliance-mapped security-audit agent, used to migrate 11 production services, and eventually packaged the whole thing into a single reusable Skill so new migrations are now one command instead of a week of manual work."

Both end on a natural hook — *"let me know if you want me to go deeper on the agent architecture, the security-audit design, or a specific bug I ran into"* — which sets up exactly the follow-up questions above, so you're steering toward ground you've already prepped.
