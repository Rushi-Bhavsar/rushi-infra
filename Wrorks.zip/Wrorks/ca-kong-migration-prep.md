# CA → Kong Migration Automation — Interview Prep

## Resume Bullets

### Full version (Experience section, 3–4 bullets)

- Migrated 11 production APIs from CA (Broadcom) Layer 7 to Kong API Gateway (Konnect), progressing from fully manual migration (branch/folder scaffolding, OAS authoring, plugin configuration, deployment validation) to a self-built AI automation pipeline.
- Architected and built 20+ specialized AI agents (Claude-based) that automate the end-to-end CA→Kong migration: CA policy XML parsing, OpenAPI spec generation, Kong plugin authoring (auth, rate limiting, threat protection, custom Lua transforms), and deployment validation against live Kong Konnect control planes.
- Designed and shipped a reusable Claude Skill that packages the entire multi-agent migration pipeline into a single invocable workflow, turning a multi-step manual process into a one-command operation for future migrations.
- Iteratively hardened the agent pipeline against real production traffic patterns and backend behaviors, correcting configuration gaps (auth schemes, environment provisioning, request/response transformation logic) that were only surfaced through live validation — encoding every fix permanently into the automation rather than one-off patches.

### Condensed version (2 bullets)

- Automated the CA (Broadcom) Layer 7 → Kong API Gateway migration process by building 20+ specialized AI agents, reducing a fully manual multi-step workflow (scaffolding, OpenAPI authoring, plugin configuration, deployment validation) to an automated pipeline used to migrate 11 production APIs.
- Packaged the automation into a reusable Claude Skill, enabling one-command execution of the full migration-to-deployment-validation pipeline for future API onboarding.

### One-liner (Skills/Projects summary line)

- **AI-Driven API Migration Automation** — Built a 20+ agent Claude automation pipeline + custom Claude Skill that migrated 11 production APIs from CA Layer 7 to Kong API Gateway, replacing a fully manual process.

> Adjust the "20+ agents" / "11 services" numbers to whatever you can stand behind in an interview.

---

## Interview Questions to Expect

Weighted toward what's most likely to actually get asked given this resume claim — the AI-automation angle draws more scrutiny than the plain "migrated APIs" part.

### 1. "Walk me through it" — opening questions
- What problem were you solving, and why was the manual process painful enough to automate?
- Walk me through one full migration, start to finish — what does the pipeline actually do at each step?
- What made you go from "just do it manually" to "build 20 agents"? What was the tipping point?

### 2. Skepticism about the AI-automation claim — expect this, prepare for it
This is the highest-probability line of questioning. Interviewers will want to know how much is genuinely automated vs. you steering an LLM turn-by-turn.

- **"How much of this did the AI actually do vs. you?"** — be ready to describe specific bugs the agents got wrong and how *you* caught and fixed them (e.g., a security config template that was wrong for half of service types, missing env vars that broke builds, incorrect Lua field mappings) — this proves you understand the system, not just prompted it.
- If you fully automated it, why did it still need correction after 11 services? What does that say about the reliability boundary?
- How do you know the agent's output is *correct*, not just plausible-looking? What's your verification story?
- What happens when an agent hallucinates a config value (e.g., a fake vault path or backend host)? How is that guarded against?

### 3. Technical depth — Kong / API Gateway domain
- What's the difference between Kong's `openid-connect` plugin doing local JWT verification vs. token introspection — and when do you need one vs. the other?
- Explain mTLS termination at the gateway layer vs. at Kong itself — why does Kong need a header-based cert-auth plugin instead of terminating TLS directly?
- How do you handle a backend that speaks SOAP/XML when the consumer-facing API is JSON? Where does that translation logic live, and why not just use a generic transformer plugin?
- What's the difference between `deck gateway validate`/`diff`/`sync` — why would you deliberately never run one of them in an automated pipeline?
- How do you reproduce a legacy gateway's custom error-handling/status-remapping behavior on a different platform?

### 4. System design — the agent architecture itself
- Why break this into ~20 single-purpose agents instead of one big agent (or one big script)?
- How do agents share context/state across steps without redoing each other's work?
- How would you extend this pipeline to support a new backend protocol (e.g., gRPC) it doesn't handle today?
- What's the failure mode if step 3 of the pipeline produces bad output — does step 4 blindly trust it? How would you build in a validation gate?

### 5. The Skill vs. Agent distinction (shows you understand the tooling, not just used it)
- What's the actual difference between an "agent" and a "skill" in this system? Why did you build the skill *after* the agents, not before?
- Could you have built the skill first and skipped building individual agents?

### 6. Rigor / validation story (this is your strongest ground — lean into it)
- How did you validate the migrated config was actually correct before calling it done — not just "it looks right"?
- Describe a real bug you found only by testing against a live system, that static review wouldn't have caught.
- Tell me about a time the automation produced something wrong, and how you traced it back to the root cause.

### 7. Impact / behavioral
- What would break if you handed this pipeline to a teammate who'd never seen it? What guardrails did you build in for that?
- What's the ROI here — time saved per migration, error rate before/after?
- What's the biggest limitation of this approach today, and what would you build next?

### Prep tip
Have 2–3 *specific* bugs ready to narrate in detail (the security-scheme variant mixup, the missing env vars breaking the build, the wrong Lua namespace/field mapping) — concrete "here's exactly what went wrong and how I found it" stories will carry you through almost every question above, including the skeptical ones.

---

## Spoken Opening

### Full version (~60–75 sec)

> "One of the projects I'm most proud of is automating our migration from a legacy API gateway — CA Layer 7 — onto Kong. When I started, every migration was fully manual: creating the branch and folder structure by hand, writing the OpenAPI spec, configuring every Kong plugin — auth, rate limiting, threat protection — one at a time, and then manually validating the deployment. It worked, but it was slow and error-prone, and the same kinds of mistakes kept resurfacing on every new service.
>
> So I started building a set of specialized AI agents — around 20 of them — each owning one piece of that pipeline: one parses the legacy export, one scaffolds the service, several author individual Kong plugins, one handles deployment validation against the live gateway. I used that pipeline to migrate 11 production APIs, and every time I found a bug — a wrong config default, a missing environment variable, incorrect logic in a custom transform — I fixed it once, in the agent itself, so every future migration inherited that fix automatically instead of me re-solving the same problem.
>
> Once the pipeline was proven against real services, I packaged the whole thing into a single reusable Skill, so kicking off a new migration is now one command instead of a multi-step manual process."

### Short version (~20 sec, for tight intros)

> "I automated our legacy-to-Kong API gateway migration — went from a fully manual, multi-step process to a pipeline of about 20 specialized AI agents, used to migrate 11 production services, and eventually packaged the whole thing into a single reusable Skill so new migrations are now one command instead of a week of manual work."

Both end on a natural hook — *"let me know if you want me to go deeper on the agent architecture or a specific bug I ran into"* — which sets up exactly the follow-up questions above, so you're steering toward ground you've already prepped.
